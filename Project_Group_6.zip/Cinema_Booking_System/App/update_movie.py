import random
from PyQt6 import QtWidgets, uic
from PyQt6.QtWidgets import QMessageBox
import pyodbc

server = r".\SQLSERVER1"
database = "Cinema_Booking_System"

connection = None
cursor = None


def get_connection():
    global connection, cursor
    if connection is None:
        connection_string = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;"
        connection = pyodbc.connect(connection_string, autocommit=False)
        cursor = connection.cursor()
    return connection, cursor


class UpdateMovieWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi("update_movie.ui", self)

        self.load_movies_into_dropdown()

        self.buttonupdate.clicked.connect(self.update_movie)
        self.retbut.clicked.connect(self.go_back)
        self.updatemovie.currentIndexChanged.connect(self.load_movie_details)

    def load_movies_into_dropdown(self):
        try:
            conn, cursor = get_connection()
            cursor.execute("SELECT Movie_Name FROM Movies")
            movies = cursor.fetchall()

            self.updatemovie.clear()
            for m in movies:
                self.updatemovie.addItem(m[0])

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load movies:\n{e}")

    def load_movie_details(self):
        movie = self.updatemovie.currentText().strip()
        if not movie:
            return

        try:
            conn, cursor = get_connection()

            cursor.execute(
                """
                SELECT Description, Running_Time, production_company, Distributed_by , Active
                FROM Movies
                WHERE Movie_Name = ?
            """,
                (movie,),
            )
            movie_data = cursor.fetchone()

            cursor.execute(
                """
                SELECT P.Producer_Name 
                FROM Producer_Movie PM
                JOIN Producers P ON PM.ProducerID = P.ProducerID
                WHERE PM.Movie_Name = ?
            """,
                (movie,),
            )
            producer_data = cursor.fetchone()

            cursor.execute("SELECT Genre FROM Genre WHERE Movie_Name = ?", (movie,))
            genre_rows = cursor.fetchall()
            genre_list = [g[0] for g in genre_rows]

            self.desupdate.setText(movie_data[0] if movie_data else "")
            self.timeupdate.setText(str(movie_data[1]) if movie_data else "")
            self.compupdate.setText(movie_data[2] if movie_data else "")
            self.distributedupdate.setText(movie_data[3] if movie_data else "")
            self.produpdate.setText(producer_data[0] if producer_data else "")
            self.genupdate.setText(", ".join(genre_list))
            self.not_active.setEnabled(False) #disabling initially

            self.status.stateChanged.connect(self.toggle_groupbox)

            opposite_active = 0 if movie_data[4] == 1 else 1
            cursor.execute(
                "SELECT Movie_Name FROM Movies WHERE Active = ?", (opposite_active,)
            )
            other_movies = cursor.fetchall()
            self.not_active.clear()  
            for m in other_movies:
                self.not_active.addItem(m[0])
        except Exception as e:
            QMessageBox.critical(self, "Load Error", f"Unable to load details:\n{e}")
    def toggle_groupbox(self):
        """Enable or disable the Not Active dropdown based on the checkbox."""
        if self.status.isChecked():
            self.not_active.setEnabled(True)
        else:
            self.not_active.setEnabled(False)

    #updating movie 
    def update_movie(self):
        movie = self.updatemovie.currentText()
        movie_from_groupbox = self.not_active.currentText()
        active_value = 1 if self.activecheckBox.isChecked() else 0
        desc = self.desupdate.text().strip()
        run = self.timeupdate.text().strip()
        company = self.compupdate.text().strip()
        dist = self.distributedupdate.text().strip()
        producer_name = self.produpdate.text().strip()
        genres_text = self.genupdate.text().strip()
        change_active = self.status.isChecked()


        conn, cursor = get_connection()

        try:
            if movie_from_groupbox and movie_from_groupbox != movie:
                if active_value == 1:
                    cursor.execute(
                        """
                        UPDATE Movies SET Active = 0
                        WHERE Movie_Name = ?
                    """,
                        (movie_from_groupbox,),
                    )
                else:
                    cursor.execute(
                        """
                        UPDATE Movies SET Active = 1
                        WHERE Movie_Name = ?
                    """,
                        (movie_from_groupbox,),
                    )

            cursor.execute(
                """
                UPDATE Movies SET
                    Description = ?, 
                    Running_Time = ?, 
                    production_company = ?, 
                    Distributed_by = ?,
                    Active = ?
                WHERE Movie_Name = ?
            """,
                (desc, run, company, dist, active_value, movie),
            )

            cursor.execute(
                "SELECT ProducerID FROM Producers WHERE Producer_Name = ?",
                (producer_name,),
            )
            p = cursor.fetchone()

            if p:
                producer_id = p[0]
            else:
                cursor.execute(
                    "INSERT INTO Producers (Producer_Name) VALUES (?)", (producer_name,)
                )
                cursor.execute("SELECT MAX(ProducerID) FROM Producers")
                producer_id = cursor.fetchone()[0]

            cursor.execute(
                """
                UPDATE Producer_Movie 
                SET ProducerID = ?
                WHERE Movie_Name = ?
            """,
                (producer_id, movie),
            )

            cursor.execute("DELETE FROM Genre WHERE Movie_Name = ?", (movie,))
            if genres_text:
                for g in genres_text.split(","):
                    genre_name = g.strip()
                    if genre_name != "":
                        cursor.execute(
                            """
                            INSERT INTO Genre (Movie_Name, Genre) VALUES (?, ?)
                        """,
                            (movie, genre_name),
                        )

            conn.commit()

            self.load_movie_details()
            self.desupdate.clear()
            self.timeupdate.clear()
            self.compupdate.clear()
            self.distributedupdate.clear()
            self.produpdate.clear()
            self.genupdate.clear()
            self.updatemovie.setCurrentIndex(0)

            QMessageBox.information(self, "Success", "Movie updated successfully!")

        except Exception as e:
            conn.rollback()
            QMessageBox.critical(self, "Update Error", f"Error updating movie:\n{e}")

    # return button
    def go_back(self):
        """Close update movie window and return to main admin window."""
        self.close()
