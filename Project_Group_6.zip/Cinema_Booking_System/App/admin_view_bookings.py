from PyQt6 import QtWidgets, uic
from PyQt6.QtWidgets import QApplication, QMainWindow, QTableWidgetItem, QHeaderView, QMessageBox
import sys
import os
import pyodbc

server = r".\SQLSERVER1"
database = 'Cinema_booking_system'
use_windows_authentication = True
username = 'your_username'
password = 'your_password'


def create_connection_string():
    if use_windows_authentication:
        return (
            f'DRIVER={{ODBC Driver 17 for SQL Server}};'
            f'SERVER={server};'
            f'DATABASE={database};'
            f'Trusted_Connection=yes;'
        )
    else:
        return (
            f'DRIVER={{ODBC Driver 17 for SQL Server}};'
            f'SERVER={server};'
            f'DATABASE={database};'
            f'UID={username};'
            f'PWD={password};'
        )


class RecordsTableWindow(QMainWindow):
    def __init__(self):
        super(RecordsTableWindow, self).__init__()
        uic.loadUi('records_table.ui', self)

        self.has_data = False 
        self.setup_table()
        self.returnButton.clicked.connect(self.close)

    def setup_table(self):
        self.tableWidget.setColumnCount(7)
        self.tableWidget.setHorizontalHeaderLabels([
            "Customer Name", "Booking ID", "Movie", "Date",
            "Time", "No of Tickets", "Booking Status"
        ])

        self.tableWidget.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tableWidget.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tableWidget.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)

    def load_data(self, movie=None, branch=None):
        try:
            conn = pyodbc.connect(create_connection_string())
            cursor = conn.cursor()

            cursor.execute("""
                SELECT COUNT(*) 
                FROM Tickets 
                WHERE Booking_Status = 'Confirmed'
            """)
            confirmed_count = cursor.fetchone()[0]
            print(f"Total confirmed tickets in database: {confirmed_count}")

            cursor.execute("SELECT DISTINCT Booking_Status FROM Tickets")
            statuses = [row[0] for row in cursor.fetchall()]
            print(f"All booking statuses in database: {statuses}")

            cursor.execute("""
                SELECT COUNT(*) 
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_NAME = 'Bookings' 
                AND COLUMN_NAME = 'BranchID'
            """)
            has_branchid = cursor.fetchone()[0] > 0
            print(f"Bookings table has BranchID column: {has_branchid}")

            query = """
                SELECT  
                    C.Customer_Name,
                    B.BookingID,
                    M.Movie_Name,
                    T.Date,
                    B.Time,
                    B.No_Of_Tickets,
                    T.Booking_Status
                FROM Customer C
                JOIN Bookings B 
                    ON C.Customer_Email = B.Customer_Email
                JOIN Movies M 
                    ON B.Movie_Name = M.Movie_Name
                JOIN Tickets T 
                    ON B.BookingID = T.BookingID
                WHERE 1=1
            """

            params = []

            query += " AND T.Booking_Status = 'Confirmed'"

            if movie and movie not in ["Select Movie", "-- Select Movie --", ""]:
                query += " AND M.Movie_Name = ?"
                params.append(movie)
                print(f"Filtering by movie: {movie}")

            if branch and branch not in ["Select Branch", "-- Select Branch --", ""] and has_branchid:
                query += " AND EXISTS (SELECT 1 FROM Cinema Cin WHERE Cin.BranchID = B.BranchID AND Cin.BranchName = ?)"
                params.append(branch)
                print(f"Filtering by branch: {branch}")

            query += " ORDER BY T.Date DESC, B.Time DESC"

            # Execute query
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
                
            results = cursor.fetchall()
            
            print(f"Found {len(results)} records")

            cursor.close()
            conn.close()

            if len(results) == 0:
                self.has_data = False
                QMessageBox.information(self, "No Records", 
                                       "No bookings found matching the selected criteria.")
                return

            self.has_data = True

            self.tableWidget.setRowCount(0)

            for row_idx, row_data in enumerate(results):
                self.tableWidget.insertRow(row_idx)
                for col_idx in range(7):  
                    value = row_data[col_idx]
                    
                    if col_idx == 3:  # Date column
                        if hasattr(value, 'strftime'):
                            value = value.strftime("%Y-%m-%d")
                    elif col_idx == 4:  # Time column
                        if hasattr(value, 'strftime'):
                            value = value.strftime("%H:%M")
                    
                    self.tableWidget.setItem(row_idx, col_idx, QTableWidgetItem(str(value)))

            # title
            title_parts = []
            if movie and movie not in ["Select Movie", "-- Select Movie --", ""]:
                title_parts.append(f"Movie: {movie}")
            if branch and branch not in ["Select Branch", "-- Select Branch --", ""]:
                title_parts.append(f"Branch: {branch}")

            if title_parts:
                self.setWindowTitle(f"Records Table - {' | '.join(title_parts)} ({len(results)} records)")
            else:
                self.setWindowTitle(f"Records Table - All Confirmed Bookings ({len(results)} records)")

        except pyodbc.Error as ex:
            self.has_data = False
            sqlstate = ex.args[0] if ex.args else "Unknown"
            error_msg = f"Database Error: {sqlstate}"
            print(error_msg)
            QMessageBox.critical(self, "Database Error", error_msg)
        except Exception as e:
            self.has_data = False
            error_msg = f"Error loading data: {str(e)}"
            print(error_msg)
            QMessageBox.critical(self, "Error", error_msg)


#VIEW BOOKINGS SCREEN

class ViewBookingsWindow(QMainWindow):
    def __init__(self):
        super(ViewBookingsWindow, self).__init__()
        uic.loadUi('view_bookings.ui', self)

        self.records_window = None
        
        self.returnButton2 = self.findChild(QtWidgets.QPushButton, "returnButton2")
        if self.returnButton2:
            self.returnButton2.clicked.connect(self.close)

        self.viewBookingsButton.clicked.connect(self.view_bookings)

        self.populate_movie_dropdown()
        self.populate_branch_dropdown()

    def populate_movie_dropdown(self):
        try:
            conn = pyodbc.connect(create_connection_string())
            cursor = conn.cursor()

            cursor.execute("SELECT DISTINCT Movie_Name FROM Movies ORDER BY Movie_Name")

            self.movieComboBox.clear()
            self.movieComboBox.addItem("Select Movie")

            for row in cursor.fetchall():
                self.movieComboBox.addItem(row[0])
            
            print(f"Loaded {self.movieComboBox.count() - 1} movies")

            cursor.close()
            conn.close()

        except Exception as e:
            print(f"Error loading movies: {e}")
            QMessageBox.warning(self, "Error", f"Could not load movies: {str(e)}")

    def populate_branch_dropdown(self):
        try:
            conn = pyodbc.connect(create_connection_string())
            cursor = conn.cursor()

            cursor.execute("SELECT DISTINCT BranchName FROM Cinema ORDER BY BranchName")

            self.branchComboBox.clear()
            self.branchComboBox.addItem("Select Branch")

            for row in cursor.fetchall():
                self.branchComboBox.addItem(row[0])
            
            print(f"Loaded {self.branchComboBox.count() - 1} branches")

            cursor.close()
            conn.close()

        except Exception as e:
            print(f"Error loading branches: {e}")
            QMessageBox.warning(self, "Error", f"Could not load branches: {str(e)}")

    def view_bookings(self):
        selected_movie = self.movieComboBox.currentText()
        selected_branch = self.branchComboBox.currentText()
        
        print(f"View Bookings clicked - Movie: {selected_movie}, Branch: {selected_branch}")

        if self.records_window:
            self.records_window.close()
            self.records_window.deleteLater()

        self.records_window = RecordsTableWindow()
        
        self.records_window.load_data(selected_movie, selected_branch)
        
        if self.records_window.has_data:
            self.records_window.show()
            self.records_window.raise_()
            self.records_window.activateWindow()
        else:
            self.records_window.deleteLater()
            self.records_window = None
