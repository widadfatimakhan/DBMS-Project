import random
from PyQt6 import QtWidgets, uic
from PyQt6.QtCore import QDate
from PyQt6.QtWidgets import QMessageBox
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
    QHeaderView,
)
import sys
import pyodbc
from add_movie import AddMovieWindow
from update_movie import UpdateMovieWindow
from admin_view_bookings import ViewBookingsWindow

server = "localhost"
database = "Cinema_Booking_System"
use_windows_authentication = True

connection = None
cursor = None


def get_connection():
    global connection, cursor
    if connection is None:
        connection_string = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;"
        connection = pyodbc.connect(connection_string, autocommit=False)
        cursor = connection.cursor()
    return connection, cursor


class SignupWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(SignupWindow, self).__init__()
        uic.loadUi("signup.ui", self)

        self.pushButton.clicked.connect(self.create_account)
        self.pushButton_2.clicked.connect(self.goto_login)

    def create_account(self):
        name = self.adname.text()
        email = self.ademail.text()
        phone = self.adphone.text()

        if not name or not email or not phone:
            QMessageBox.warning(self, "Input Error", "All fields are required!")
            return
        if not phone.isdigit():
            QMessageBox.warning(
                self,
                "Invalid Phone Number",
                "Phone number should contain digits only (no letters or symbols).",
            )
            return
        try:
            connection, cursor = get_connection()

            # Check if admin already exists
            cursor.execute(
                "SELECT * FROM Admin WHERE Admin_Name = ? OR Admin_Email = ?",
                (name, email),
            )
            if cursor.fetchone():
                QMessageBox.warning(
                    self, "Duplicate Error", "Name or email already exists!"
                )
                return

            # Insert new admin
            cursor.execute(
                """
                INSERT INTO Admin(Admin_Name, Admin_Email, Contact_No)
                VALUES (?, ?, ?)
            """,
                (name, email, phone),
            )

            connection.commit()

            cursor.execute("SELECT MAX(AdminID) FROM Admin")
            result = cursor.fetchone()
            new_admin_id = result[0] if result else "N/A"

            QMessageBox.information(
                self,
                "Success",
                f"Account created successfully!\nYour Admin ID is: {new_admin_id}",
            )

        except Exception as e:
            connection.rollback()
            QMessageBox.critical(self, "Error", f"Transaction rolled back: {e}")

    def goto_login(self):
        self.login_window = LoginWindow()
        self.login_window.show()
        self.close()


# LOGIN WINDOW
class LoginWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(LoginWindow, self).__init__()
        uic.loadUi("adminlogin.ui", self)

        self.loginbutton.clicked.connect(self.login_admin)

    def login_admin(self):
        admin_id = self.adminid.text()
        name = self.adminame.text()
        email = self.adminemail.text()

        try:
            connection, cursor = get_connection()

            cursor.execute(
                """
                SELECT * FROM Admin
                WHERE AdminID = ? AND Admin_Name = ? AND Admin_Email = ?
            """,
                (admin_id, name, email),
            )

            if cursor.fetchone():
                self.main = AdminMainWindow()
                self.main.show()
                self.close()
            else:
                QMessageBox.warning(self, "Error", "Invalid Details!")

        except Exception as e:
            connection.rollback()
            QMessageBox.critical(self, "Error", f"Rolled Back: {e}")


# ADMIN MAIN WINDOW
class AdminMainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super(AdminMainWindow, self).__init__()
        uic.loadUi("adminmainwindow.ui", self)

        self.addbutton.clicked.connect(self.add_movie)
        self.updatebutton.clicked.connect(self.update_movie)
        self.viewbutton.clicked.connect(self.view_bookings)
        self.logoutbutton_2.clicked.connect(self.logging_out)

        self.view_bookings_window = None

    def open_add_movie(self):
        self.add_movie_window = AddMovieWindow()
        self.add_movie_window.show()

    def open_update_movie(self):
        self.update_movie_window = UpdateMovieWindow()
        self.update_movie_window.show()

    def add_movie(self):
        self.addbutton.clicked.connect(self.open_add_movie)

    def update_movie(self):
        self.updatebutton.clicked.connect(self.open_update_movie)

    def view_bookings(self):
        if self.view_bookings_window:
            self.view_bookings_window.close()
            self.view_bookings_window.deleteLater()

        # Open new ViewBookingsWindow
        self.view_bookings_window = ViewBookingsWindow()
        self.view_bookings_window.show()
        self.view_bookings_window.raise_()
        self.view_bookings_window.activateWindow()

    def rollback_all(self):
        connection, _ = get_connection()
        connection.rollback()
        QMessageBox.information(self, "Rolled Back", "Everything undone!")

    def logging_out(self):
        sys.exit(app.exec())


app = QtWidgets.QApplication(sys.argv)
window = SignupWindow()
window.show()
sys.exit(app.exec())
