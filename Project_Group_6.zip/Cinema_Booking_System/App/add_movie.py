import random
from PyQt6 import QtWidgets, uic
from PyQt6.QtCore import QDate
from PyQt6.QtWidgets import QMessageBox
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
    QHeaderView,
)
import sys
import pyodbc


server = r".\SQLSERVER1"
database = "Cinema_Booking_System"
use_windows_authentication = True

connection = None
cursor = None

def get_connection():
    global connection, cursor
    if connection is None:
        connection_string = f"DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={server};DATABASE={database};Trusted_Connection=yes;"
        connection = pyodbc.connect(connection_string, autocommit=False)
        cursor = connection.cursor()
    return connection, cursor
class AddMovieWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()

        try:
            uic.loadUi("Add_movies.ui", self)
        except Exception as e:
            QMessageBox.critical(self, "UI Load Error",
                                 f"Could not load 'Add_movies.ui'. Error:\n{e}")
            sys.exit(1)

        self.swapMovieDropdown = self.findChild(QtWidgets.QComboBox, "swapMovieDropdown")
        self.movieToAdd = self.findChild(QtWidgets.QLineEdit, "movieToAdd")
        self.des = self.findChild(QtWidgets.QLineEdit, "des")
        self.prod = self.findChild(QtWidgets.QLineEdit, "prod")
        self.runningTime = self.findChild(QtWidgets.QLineEdit, "runningTime")
        self.prodComp = self.findChild(QtWidgets.QLineEdit, "prodcomp")
        self.distributedBy = self.findChild(QtWidgets.QLineEdit, "distributedBy")
        self.genre = self.findChild(QtWidgets.QLineEdit, "genre")

        self.addMovieButton = self.findChild(QtWidgets.QPushButton, "adbutton")
        self.returnButton = self.findChild(QtWidgets.QPushButton, "rt")
        self.addMovieButton.clicked.connect(self.add_movie)
        self.returnButton.clicked.connect(self.close)

        self.load_movies_into_dropdown()

    #loading for dropdown
    def load_movies_into_dropdown(self):
        try:
            conn, cursor = get_connection()
            cursor.execute("SELECT Movie_Name FROM Movies WHERE Active = 1 ORDER BY Movie_Name;")
            movies = cursor.fetchall()

            self.swapMovieDropdown.clear()
            for movie in movies:
                self.swapMovieDropdown.addItem(movie[0])

        except Exception as e:
            QMessageBox.critical(self, "Database Error", f"Could not load movies:\n{e}")


    #adding movies
    def add_movie(self):
        new_movie = self.movieToAdd.text().strip()
        desc = self.des.text().strip()
        producers_text = self.prod.text().strip()
        run = self.runningTime.text().strip()
        company = self.prodcomp.text().strip()
        dist = self.distributedBy.text().strip()
        genres_text = self.genre.text().strip()  # Get genres input

        if new_movie == "":
            QMessageBox.warning(self, "Input Error", "Please enter the movie name.")
            return

        if not run.isdigit():
            QMessageBox.warning(self, "Input Error", "Running time must be a number.")
            return

        try:
            conn, cursor = get_connection()

            #Insert movie if not exists, set Active = 1
            cursor.execute("""
            IF NOT EXISTS (SELECT 1 FROM Movies WHERE Movie_Name = ?)
            BEGIN
                INSERT INTO Movies
                (Movie_Name, Description, Running_Time, Release_Date, Age_Restriction,
                production_company, Distributed_by, Active)
                VALUES (?, ?, ?, GETDATE(), 'U', ?, ?, 1)
            END
            """, (new_movie, new_movie, desc, run, company, dist))

            if producers_text:
                producer_list = [p.strip() for p in producers_text.split(",") if p.strip()]

                for producer_name in producer_list:
                    # Insert producer if not exists
                    cursor.execute("SELECT ProducerID FROM Producers WHERE Producer_Name = ?", (producer_name,))
                    result = cursor.fetchone()
                    if result:
                        producer_id = result[0]
                    else:
                        cursor.execute("INSERT INTO Producers(Producer_Name) VALUES (?)", (producer_name,))
                        cursor.execute("SELECT MAX(ProducerID) FROM Producers")
                        producer_id = cursor.fetchone()[0]

                    # Linking producer with movie
                    cursor.execute("""
                    IF NOT EXISTS (SELECT 1 FROM Producer_Movie WHERE Movie_Name=? AND ProducerID=?)
                        INSERT INTO Producer_Movie(Movie_Name, ProducerID) VALUES (?, ?)
                    """, (new_movie, producer_id, new_movie, producer_id))

            # Insert genres 
            if genres_text:
                for g in genres_text.split(","):
                    genre_name = g.strip()
                    if genre_name:
                        cursor.execute("""
                        IF NOT EXISTS (SELECT 1 FROM Genre WHERE Movie_Name=? AND Genre=?)
                            INSERT INTO Genre(Movie_Name, Genre) VALUES (?, ?)
                        """, (new_movie, genre_name, new_movie, genre_name))

            #  marking  old movie inactive in DB
            old_index = self.swapMovieDropdown.currentIndex()
            old_movie = self.swapMovieDropdown.currentText()

            if old_movie != new_movie:
                cursor.execute("UPDATE Movies SET Active = 0 WHERE Movie_Name = ?", (old_movie,))
                cursor.execute("UPDATE Movies SET Active = 1 WHERE Movie_Name = ?", (new_movie,))

            # Inserting into Cinema_Movie for both branches
            branch_ids = [1, 2]  
            for branch_id in branch_ids:
                cursor.execute("""
                    IF NOT EXISTS (SELECT 1 FROM Cinema_Movie WHERE Movie_Name=? AND BranchID=?)
                        INSERT INTO Cinema_Movie(Movie_Name, BranchID) VALUES (?, ?)
                """, (new_movie, branch_id, new_movie, branch_id))

            conn.commit()

        except Exception as e:
            conn.rollback()
            QMessageBox.critical(self, "Insert Error", f"Error inserting movie:\n{e}")
            return

        self.swapMovieDropdown.setItemText(old_index, new_movie)

        QMessageBox.information(
            self, "Success",
            f"Movie added successfully.\nUI swapped '{old_movie}' with '{new_movie}'."
        )
